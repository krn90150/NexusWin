const express = require('express');
const path = require('path');
const admin = require('firebase-admin');

const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://nexuswin-aa829-default-rtdb.firebaseio.com"
});

const db = admin.firestore();
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const ADMIN_EMAIL = "parii90150@gmail.com";

// Secure Admin Middleware
function verifyAdminSession(req, res, next) {
  const adminEmail = req.body.email || req.query.email || req.headers['x-admin-email'];
  if (adminEmail === ADMIN_EMAIL) {
    next();
  } else {
    res.status(403).json({ success: false, error: "Unauthorized: Admin access only" });
  }
}

// Routes
app.get('/', (req, res) => { res.render('login'); });
app.get('/dashboard', (req, res) => { res.render('index'); });
app.get('/profile', (req, res) => { res.render('profile'); });
app.get('/withdrawal', (req, res) => { res.render('withdrawal'); });
app.get('/game/color-prediction', (req, res) => { res.render('game-color'); });
app.get('/game/aviator', (req, res) => { res.render('game-aviator'); });
app.get('/game/slots', (req, res) => { res.render('game-slots'); });

app.get('/admin/dashboard', async (req, res) => {
  try {
    const depositsSnap = await db.collection('pending_deposits').where('status', '==', 'PENDING').get();
    const withdrawalsSnap = await db.collection('pending_withdrawals').where('status', '==', 'PENDING').get();
    
    const deposits = depositsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    const withdrawals = withdrawalsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    res.render('admin-panel', { adminEmail: ADMIN_EMAIL, deposits, withdrawals });
  } catch (error) {
    res.status(500).send("Error loading admin panel: " + error.message);
  }
});

// --- REAL USER DATA API ---
app.post('/api/user/sync', async (req, res) => {
  const { uid, email } = req.body;
  if (!uid) return res.status(400).json({ error: 'UID missing' });

  const userRef = db.collection('users').doc(uid);
  try {
    const doc = await userRef.get();
    if (!doc.exists) {
      await userRef.set({
        email: email || '',
        walletBalance: 0,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
      res.status(200).json({ balance: 0 });
    } else {
      res.status(200).json({ balance: doc.data().walletBalance || 0 });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// --- DEPOSIT & WITHDRAWAL APIs ---
app.post('/api/user/deposit-request', async (req, res) => {
  const { uid, amount, utrNumber } = req.body;
  if (!uid || !amount || !utrNumber) return res.status(400).json({ error: 'Missing required fields' });

  try {
    await db.collection('pending_deposits').add({
      uid, amount: Number(amount), utrNumber, status: 'PENDING', timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    res.status(200).json({ success: true, message: 'Deposit request submitted successfully.' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/user/withdrawal-request', async (req, res) => {
  const { uid, amount, upiId } = req.body;
  if (!uid || !amount || !upiId) return res.status(400).json({ error: 'Missing required fields' });

  const userRef = db.collection('users').doc(uid);
  try {
    await db.runTransaction(async (transaction) => {
      const userDoc = await transaction.get(userRef);
      const currentBalance = userDoc.exists ? (userDoc.data().walletBalance || 0) : 0;
      if (currentBalance < Number(amount)) throw new Error('Insufficient wallet balance');

      transaction.update(userRef, { walletBalance: currentBalance - Number(amount) });
      const withdrawalRef = db.collection('pending_withdrawals').doc();
      transaction.set(withdrawalRef, {
        uid, amount: Number(amount), upiId, status: 'PENDING', timestamp: admin.firestore.FieldValue.serverTimestamp()
      });
    });
    res.status(200).json({ success: true, message: 'Withdrawal request submitted successfully.' });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// Secure Deposit Approval API
app.post('/api/admin/approve-deposit', verifyAdminSession, async (req, res) => {
  const { depositId, uid, amount } = req.body;
  const userRef = db.collection('users').doc(uid);
  const depositRef = db.collection('pending_deposits').doc(depositId);

  try {
    await db.runTransaction(async (transaction) => {
      const userDoc = await transaction.get(userRef);
      const currentBalance = userDoc.exists ? (userDoc.data().walletBalance || 0) : 0;
      transaction.set(userRef, { walletBalance: currentBalance + Number(amount) }, { merge: true });
      transaction.update(depositRef, { status: 'APPROVED' });
    });
    res.status(200).json({ success: true, message: 'Deposit approved and balance updated!' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Secure Withdrawal Approval API
app.post('/api/admin/approve-withdrawal', verifyAdminSession, async (req, res) => {
  const { withdrawalId } = req.body;
  try {
    await db.collection('pending_withdrawals').doc(withdrawalId).update({ status: 'APPROVED' });
    res.status(200).json({ success: true, message: 'Withdrawal payout marked as approved!' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// --- GAMES APIs (Color Prediction & Aviator) ---
app.post('/api/game/play-color', async (req, res) => {
  const { uid, betAmount, choice } = req.body;
  const userRef = db.collection('users').doc(uid);

  try {
    const result = await db.runTransaction(async (transaction) => {
      const userDoc = await transaction.get(userRef);
      if (!userDoc.exists) throw new Error('User not found');
      const currentBalance = userDoc.data().walletBalance || 0;
      if (currentBalance < Number(betAmount)) throw new Error('Insufficient balance');

      const colors = ['green', 'red', 'violet', 'green', 'red'];
      const winningColor = colors[Math.floor(Math.random() * colors.length)];
      let isWin = (choice === winningColor);
      let payout = isWin ? (choice === 'violet' ? Number(betAmount) * 4.5 : Number(betAmount) * 2) : 0;

      const finalBalance = currentBalance - Number(betAmount) + payout;
      transaction.update(userRef, { walletBalance: finalBalance });
      return { winningColor, isWin, payout, newBalance: finalBalance };
    });
    res.status(200).json({ success: true, ...result });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.post('/api/game/play-aviator', async (req, res) => {
  const { uid, betAmount, cashOutMultiplier } = req.body;
  const userRef = db.collection('users').doc(uid);

  try {
    const result = await db.runTransaction(async (transaction) => {
      const userDoc = await transaction.get(userRef);
      if (!userDoc.exists) throw new Error('User not found');
      const currentBalance = userDoc.data().walletBalance || 0;
      if (currentBalance < Number(betAmount)) throw new Error('Insufficient balance');

      const crashPoint = Number((Math.random() * 4 + 1).toFixed(2));
      let isWin = Number(cashOutMultiplier) <= crashPoint;
      let payout = isWin ? Number(betAmount) * Number(cashOutMultiplier) : 0;

      const finalBalance = currentBalance - Number(betAmount) + payout;
      transaction.update(userRef, { walletBalance: finalBalance });
      return { crashPoint, isWin, payout, newBalance: finalBalance };
    });
    res.status(200).json({ success: true, ...result });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// --- TRANSACTION HISTORY API ---
app.get('/api/user/history/:uid', async (req, res) => {
  const { uid } = req.params;
  try {
    const depositsSnap = await db.collection('pending_deposits').where('uid', '==', uid).get();
    const withdrawalsSnap = await db.collection('pending_withdrawals').where('uid', '==', uid).get();

    const deposits = depositsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    const withdrawals = withdrawalsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    res.status(200).json({ success: true, deposits, withdrawals });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/history', (req, res) => { res.render('history'); });

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`NexusWin server is running on port ${PORT}`);
});
