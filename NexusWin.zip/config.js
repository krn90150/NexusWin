const admin = require('firebase-admin');

// Initialize Firebase Admin (Aapko Firebase console se serviceAccountKey.json download karke yahan link karna hoga)
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://nexuswin-aa829-default-rtdb.firebaseio.com"
});

const db = admin.firestore();
const ADMIN_EMAIL = "parii90150@gmail.com";

module.exports = { admin, db, ADMIN_EMAIL };
